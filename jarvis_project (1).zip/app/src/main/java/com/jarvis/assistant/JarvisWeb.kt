package com.jarvis.assistant

import android.annotation.SuppressLint
import android.graphics.Color
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

object JarvisWeb {
    // JARVIS page served by the Termux agent (python jarvis_agent.py)
    const val URL = "http://localhost:8000/jarvis_orb.html"

    private const val ERROR_HTML =
        "<html><body style='background:#050b18;color:#22d3ee;font-family:sans-serif;padding:24px'>" +
        "<h3>JARVIS server is not running</h3>" +
        "<p>Open Termux and run:<br><b>cd ~/jarvis &amp;&amp; python jarvis_agent.py</b></p>" +
        "<p>Then <a style='color:#fff' href='" + URL + "'>tap here to retry</a>.</p></body></html>"

    @SuppressLint("SetJavaScriptEnabled")
    fun setup(web: WebView) {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.cacheMode = WebSettings.LOAD_NO_CACHE
        web.setBackgroundColor(Color.parseColor("#050b18"))
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                request.grant(request.resources)
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    view.loadDataWithBaseURL(null, ERROR_HTML, "text/html", "UTF-8", null)
                }
            }
        }
    }
}

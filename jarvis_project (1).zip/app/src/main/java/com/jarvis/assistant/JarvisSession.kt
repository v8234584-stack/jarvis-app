package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionSession
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONObject

// The panel that opens over any app when the Home button is long-pressed.
class JarvisSession(private val ctx: Context) : VoiceInteractionSession(ctx) {
    private var web: WebView? = null
    private var rec: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreateContentView(): View {
        val dm = ctx.resources.displayMetrics
        val root = FrameLayout(ctx)
        root.setBackgroundColor(Color.TRANSPARENT)
        root.setOnClickListener { hide() }          // tap outside the panel to close
        val w = WebView(ctx)
        JarvisWeb.setup(w)
        w.loadUrl(JarvisWeb.URL)
        root.addView(
            w,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (dm.heightPixels * 0.62).toInt(),
                Gravity.TOP
            )
        )
        web = w
        return root
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        handler.postDelayed({ startListening() }, 900)
    }

    override fun onHide() {
        stopListening()
        super.onHide()
    }

    override fun onDestroy() {
        stopListening()
        web?.destroy()
        web = null
        super.onDestroy()
    }

    private fun stopListening() {
        handler.removeCallbacksAndMessages(null)
        try {
            rec?.cancel()
            rec?.destroy()
        } catch (e: Exception) {
        }
        rec = null
    }

    private fun startListening() {
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(ctx, "Open the JARVIS app once and allow the microphone", Toast.LENGTH_LONG).show()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            Toast.makeText(ctx, "No speech recognizer found on this phone", Toast.LENGTH_LONG).show()
            return
        }
        stopListening()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                // 6 = no speech, 7 = no match: just stay quiet
                if (error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT && error != SpeechRecognizer.ERROR_NO_MATCH) {
                    Toast.makeText(ctx, "Mic error " + error, Toast.LENGTH_SHORT).show()
                }
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull()
                if (!text.isNullOrBlank()) sendToPage(text)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        r.startListening(i)
        rec = r
    }

    // Types the spoken text into JARVIS's own input box and presses GO (the page's design is not touched).
    private fun sendToPage(text: String) {
        val q = JSONObject.quote(text)
        val js = "(function(t){" +
            "var ins=[].slice.call(document.querySelectorAll('input'));" +
            "var i=ins.filter(function(x){return /sollu|help/i.test(x.placeholder||'');})[0]||ins[0];" +
            "if(!i)return;" +
            "var set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;" +
            "set.call(i,t);i.dispatchEvent(new Event('input',{bubbles:true}));" +
            "var bs=[].slice.call(document.querySelectorAll('button'));" +
            "var g=bs.filter(function(b){return (b.innerText||'').trim().toUpperCase()==='GO';})[0];" +
            "if(g)g.click();" +
            "})(" + q + ")"
        web?.evaluateJavascript(js, null)
    }
}

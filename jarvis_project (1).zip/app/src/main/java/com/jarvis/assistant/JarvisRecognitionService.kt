package com.jarvis.assistant

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

// Android asks every assistant app to declare a recognition service.
// This one simply forwards to Google's speech recognizer, so voice typing keeps working everywhere.
class JarvisRecognitionService : RecognitionService() {
    private var delegate: SpeechRecognizer? = null

    override fun onStartListening(recognizerIntent: Intent, listener: Callback) {
        delegate?.destroy()
        val d = try {
            SpeechRecognizer.createSpeechRecognizer(
                this,
                ComponentName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.voicesearch.serviceapi.GoogleRecognitionService"
                )
            )
        } catch (e: Exception) {
            null
        }
        if (d == null) {
            listener.error(SpeechRecognizer.ERROR_CLIENT)
            return
        }
        d.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listener.readyForSpeech(params ?: Bundle()) }
            override fun onBeginningOfSpeech() { listener.beginningOfSpeech() }
            override fun onRmsChanged(rmsdB: Float) { listener.rmsChanged(rmsdB) }
            override fun onBufferReceived(buffer: ByteArray?) { listener.bufferReceived(buffer ?: ByteArray(0)) }
            override fun onEndOfSpeech() { listener.endOfSpeech() }
            override fun onError(error: Int) { listener.error(error) }
            override fun onResults(results: Bundle?) { listener.results(results ?: Bundle()) }
            override fun onPartialResults(partialResults: Bundle?) { listener.partialResults(partialResults ?: Bundle()) }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        d.startListening(recognizerIntent)
        delegate = d
    }

    override fun onStopListening(listener: Callback) {
        delegate?.stopListening()
    }

    override fun onCancel(listener: Callback) {
        delegate?.cancel()
        delegate?.destroy()
        delegate = null
    }

    override fun onDestroy() {
        delegate?.destroy()
        delegate = null
        super.onDestroy()
    }
}

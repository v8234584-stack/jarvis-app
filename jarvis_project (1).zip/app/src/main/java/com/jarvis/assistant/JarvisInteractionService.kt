package com.jarvis.assistant

import android.service.voice.VoiceInteractionService

class JarvisInteractionService : VoiceInteractionService()
